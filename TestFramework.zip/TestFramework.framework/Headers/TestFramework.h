//
//  TestFramework.h
//  TestFramework
//
//  Created by Nikhilesh on 29/05/17.
//  Copyright © 2017 CAPILLARY. All rights reserved.
//

#import <UIKit/UIKit.h>
@class TestBO;
//! Project version number for TestFramework.
FOUNDATION_EXPORT double TestFrameworkVersionNumber;

//! Project version string for TestFramework.
FOUNDATION_EXPORT const unsigned char TestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework/PublicHeader.h>


